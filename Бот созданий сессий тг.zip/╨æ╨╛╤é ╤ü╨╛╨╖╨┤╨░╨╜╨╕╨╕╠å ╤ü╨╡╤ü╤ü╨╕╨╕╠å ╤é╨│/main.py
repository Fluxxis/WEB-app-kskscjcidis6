#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Telegram-бот с inline UI, менеджером прокси и Telethon/Pyrogram сессий.
Авто-проверка и установка нужных библиотек.
"""

import subprocess
import sys

# ---------------- Auto-install required packages ----------------
required_packages = [
    "aiogram>=3.4.1",
    "telethon>=1.35.0",
    "pyrogram>=2.0.106",
    "tgcrypto>=1.2.5",
    "pysocks>=1.7.1",
    "aiofiles>=23.2.1",
    "cryptography>=42.0.0",
    "python-dotenv>=1.0.1",
]

def install(package):
    subprocess.check_call([sys.executable, "-m", "pip", "install", package])

for pkg in required_packages:
    try:
        __import__(pkg.split("==")[0].split(">=")[0])
    except ImportError:
        print(f"[INFO] Устанавливаю {pkg}...")
        install(pkg)
# ------------------------------------------------------------------

# Теперь идут все остальные импорты, как в твоём коде
import asyncio
import os
import time
import logging
from typing import List, Optional

from aiogram import Bot, Dispatcher, F
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton, FSInputFile
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage

import aiofiles
import socks
import socket

# Telethon & Pyrogram
from telethon import TelegramClient, errors as tele_errors
from pyrogram import Client as PyroClient
from pyrogram.errors import SessionPasswordNeeded

# ---------- CONFIG ----------
API_TOKEN = "8524456895:AAGOscfi11Nmfu-MvGzJ4a2KOpQXDLtk6_A"  # замените
# Где храним файлы
DATA_DIR = "data"
PROXY_IN_DIR = os.path.join(DATA_DIR, "in")
PROXY_OUT_DIR = os.path.join(DATA_DIR, "out")
SESSIONS_DIR = os.path.join(DATA_DIR, "sessions")
os.makedirs(PROXY_IN_DIR, exist_ok=True)
os.makedirs(PROXY_OUT_DIR, exist_ok=True)
os.makedirs(SESSIONS_DIR, exist_ok=True)

# Логи
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
# ----------------------------

# FSM states
class MainStates(StatesGroup):
    waiting_for_proxy_file = State()
    waiting_for_proxy_count = State()
    wait_telethon_api = State()
    wait_telethon_phone = State()
    wait_telethon_code = State()
    wait_telethon_password = State()
    wait_pyro_api = State()
    wait_pyro_phone = State()
    wait_pyro_code = State()
    wait_pyro_password = State()
    wait_upload_session = State()

# Инициализация aiogram
bot = Bot(API_TOKEN, parse_mode="HTML")
dp = Dispatcher(storage=MemoryStorage())

# ---------- Keyboards ----------
def main_kb() -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton("🌐 Proxy Manager", callback_data="proxy_menu")],
        [InlineKeyboardButton("👤 Sessions (Telethon/Pyro)", callback_data="sessions_menu")],
        [InlineKeyboardButton("ℹ️ About / Help", callback_data="about")],
    ])
    return kb

def proxy_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton("📤 Upload TXT with proxies", callback_data="upload_proxy")],
        [InlineKeyboardButton("⬅️ Back", callback_data="back_main")],
    ])

def sessions_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton("➕ Create Telethon session", callback_data="create_telethon")],
        [InlineKeyboardButton("➕ Create Pyrogram session", callback_data="create_pyrogram")],
        [InlineKeyboardButton("📥 Upload existing .session", callback_data="upload_session")],
        [InlineKeyboardButton("⬅️ Back", callback_data="back_main")],
    ])

# ---------- Utility: parse proxies ----------
def parse_proxies_text(text: str) -> List[str]:
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    # keep only plausible socks-like lines
    parsed = []
    for l in lines:
        # basic validation: ip:port or ip:port:user:pass
        parts = l.split(":")
        if len(parts) >= 2:
            # port numeric?
            try:
                _ = int(parts[1])
                parsed.append(l)
            except:
                continue
    return parsed

# ---------- Proxy checker (async, concurrent) ----------
async def check_socks5_once(proxy: str, timeout: float = 6.0) -> Optional[str]:
    """
    Проверяет один SOCKS5 proxy.
    Формат: ip:port или ip:port:user:pass (или ip:port:user:pass:...)
    Возвращает сам proxy строкой, если рабочий, иначе None.
    """
    parts = proxy.split(":")
    if len(parts) < 2:
        return None
    host = parts[0]
    try:
        port = int(parts[1])
    except:
        return None
    username = None
    password = None
    if len(parts) >= 4:
        username = parts[2]
        password = parts[3]

    loop = asyncio.get_running_loop()

    def _sync_check():
        s = socks.socksocket()
        try:
            if username is not None and password is not None:
                s.set_proxy(socks.SOCKS5, host, port, True, username, password)
            else:
                s.set_proxy(socks.SOCKS5, host, port)
            s.settimeout(timeout)
            # соединение к telegram.org:443 (TLS)
            s.connect(("149.154.167.50", 443))  # один из IP telegram.org (обход DNS)
            s.close()
            return True
        except Exception as e:
            try:
                s.close()
            except: pass
            return False

    ok = await loop.run_in_executor(None, _sync_check)
    return proxy if ok else None

async def check_proxies_bulk(proxies: List[str], concurrency: int = 50) -> List[str]:
    sem = asyncio.Semaphore(concurrency)
    results = []

    async def worker(p):
        async with sem:
            try:
                res = await check_socks5_once(p)
                if res:
                    results.append(res)
            except Exception as e:
                logger.debug("checker error %s %s", p, e)

    tasks = [asyncio.create_task(worker(p)) for p in proxies]
    await asyncio.gather(*tasks)
    return results

# ---------- Handlers ----------
@dp.message(Command("start"))
async def cmd_start(m: Message):
    await m.answer(
        "<b>⚙️ Proxy & Session Manager</b>\n\n"
        "Выбери действие:",
        reply_markup=main_kb()
    )

@dp.callback_query(F.data == "about")
async def about_cb(cb: CallbackQuery):
    await cb.message.edit_text(
        "<b>Proxy & Session Manager</b>\n\n"
        "Этот бот помогает работать с SOCKS5 проксями и вашими собственными Telethon/Pyrogram сессиями.\n\n"
        "<b>Важно:</b> не используйте этот инструмент для несанкционированного доступа к чужим аккаунтам.\n\n"
        "Функции:\n"
        "• Загрузка TXT с проксями → выбор, сколько проверить → проверка → готовый TXT с рабочими проксями\n"
        "• Создание Telethon/Pyrogram сессии через ввод api_id/api_hash/phone/code (только для ваших аккаунтов)\n"
        "• Загрузка и экспорт .session файлов\n",
        reply_markup=main_kb()
    )

@dp.callback_query(F.data == "proxy_menu")
async def proxy_menu_cb(cb: CallbackQuery):
    await cb.message.edit_text("🌐 <b>SOCKS5 Manager</b>\nВыбери действие:", reply_markup=proxy_kb())

@dp.callback_query(F.data == "upload_proxy")
async def upload_proxy_cb(cb: CallbackQuery, state: FSMContext):
    await state.set_state(MainStates.waiting_for_proxy_file)
    await cb.message.answer("📄 Пожалуйста, отправь TXT файл с проксями.\nФормат: <code>ip:port</code> или <code>ip:port:user:pass</code> (по одной на строку).")

@dp.message(MainStates.waiting_for_proxy_file, F.document)
async def handle_proxy_file(msg: Message, state: FSMContext):
    # скачиваем файл
    doc = msg.document
    if not doc.file_name.lower().endswith(".txt"):
        await msg.answer("Пожалуйста, загрузите TXT файл.")
        return
    save_path = os.path.join(PROXY_IN_DIR, f"{int(time.time())}_{doc.file_name}")
    await msg.document.download(save_path)
    async with aiofiles.open(save_path, mode="r", encoding="utf-8", errors="ignore") as f:
        text = await f.read()
    proxies = parse_proxies_text(text)
    if not proxies:
        await msg.answer("Файл не содержит корректных прокси.")
        await state.clear()
        return
    await state.update_data(proxy_file=save_path, proxies=proxies)
    await state.set_state(MainStates.waiting_for_proxy_count)
    await msg.answer(f"Файл принят. Найдено {len(proxies)} прокси.\nСколько нужно проверить? Введи число (max {len(proxies)}).")

@dp.message(MainStates.waiting_for_proxy_count)
async def handle_proxy_count(msg: Message, state: FSMContext):
    data = await state.get_data()
    proxies = data.get("proxies", [])
    try:
        cnt = int(msg.text.strip())
        if cnt <= 0:
            raise ValueError()
    except:
        await msg.answer("Нужно ввести положительное число.")
        return
    cnt = min(cnt, len(proxies))
    await msg.answer(f"Начинаю проверку {cnt} проксей. Это может занять время...")
    subset = proxies[:cnt]
    # проверяем асинхронно
    good = await check_proxies_bulk(subset, concurrency=50)
    out_path = os.path.join(PROXY_OUT_DIR, f"good_{int(time.time())}.txt")
    async with aiofiles.open(out_path, mode="w", encoding="utf-8") as f:
        await f.write("\n".join(good))
    await msg.answer_document(document=FSInputFile(out_path), caption=f"✅ Готово. Рабочих прокси: {len(good)}")
    await state.clear()

@dp.callback_query(F.data == "back_main")
async def back_main(cb: CallbackQuery):
    await cb.message.edit_text("Выберите действие:", reply_markup=main_kb())

# ---------- Sessions menu ----------
@dp.callback_query(F.data == "sessions_menu")
async def sessions_menu_cb(cb: CallbackQuery):
    await cb.message.edit_text("👤 <b>Sessions Manager</b>\nВыберите действие:", reply_markup=sessions_kb())

@dp.callback_query(F.data == "upload_session")
async def upload_session_cb(cb: CallbackQuery, state: FSMContext):
    await state.set_state(MainStates.wait_upload_session)
    await cb.message.answer("📥 Отправь файл .session (Telethon или Pyrogram).")

@dp.message(MainStates.wait_upload_session, F.document)
async def handle_upload_session(msg: Message, state: FSMContext):
    doc = msg.document
    if not (doc.file_name.lower().endswith(".session") or doc.file_name.lower().endswith(".session-journal")):
        await msg.answer("Пожалуйста, отправьте файл с расширением .session (или .session-journal).")
        return
    save_name = f"{int(time.time())}_{doc.file_name}"
    save_path = os.path.join(SESSIONS_DIR, save_name)
    await msg.document.download(save_path)
    await msg.answer_document(document=FSInputFile(save_path), caption="Файл сохранён и доступен вам (это просто бэкап).")
    await state.clear()

# ---------- Create Telethon session flow ----------
@dp.callback_query(F.data == "create_telethon")
async def cb_create_telethon(cb: CallbackQuery, state: FSMContext):
    await state.set_state(MainStates.wait_telethon_api)
    await cb.message.answer(
        "Создание Telethon-сессии.\n"
        "Отправь api_id и api_hash в формате <code>api_id:api_hash</code> (оба значения получены через my.telegram.org)."
    )

@dp.message(MainStates.wait_telethon_api)
async def telethon_receive_api(msg: Message, state: FSMContext):
    text = msg.text.strip()
    if ":" not in text:
        await msg.answer("Неверный формат. Ожидаю <code>api_id:api_hash</code>.")
        return
    api_id_s, api_hash = text.split(":", 1)
    try:
        api_id = int(api_id_s.strip())
    except:
        await msg.answer("api_id должен быть числом.")
        return
    await state.update_data(telethon_api_id=api_id, telethon_api_hash=api_hash.strip())
    await state.set_state(MainStates.wait_telethon_phone)
    await msg.answer("Теперь введите номер телефона аккаунта (в международном формате, например +4917...).")

@dp.message(MainStates.wait_telethon_phone)
async def telethon_receive_phone(msg: Message, state: FSMContext):
    phone = msg.text.strip()
    data = await state.get_data()
    api_id = data["telethon_api_id"]
    api_hash = data["telethon_api_hash"]
    # create a unique session name per user
    session_name = f"telethon_{msg.from_user.id}_{int(time.time())}"
    session_path = os.path.join(SESSIONS_DIR, f"{session_name}.session")
    client = TelegramClient(session_path, api_id, api_hash)
    await msg.answer("Отправляю код на номер... просьба подождать код и отправить его сюда.")
    try:
        await client.connect()
        sent = await client.send_code_request(phone)
    except tele_errors.PhoneNumberInvalidError:
        await msg.answer("Неправильный номер.")
        await client.disconnect()
        await state.clear()
        return
    except Exception as e:
        await msg.answer(f"Ошибка при запросе кода: {e}")
        await client.disconnect()
        await state.clear()
        return
    # сохраняем client info в state (не сериализуем клиент — сохраним данные для восстановления)
    await state.update_data(telethon_session_path=session_path, telethon_phone=phone)
    await state.set_state(MainStates.wait_telethon_code)
    await msg.answer("Введите код, который пришёл в Telegram SMS/в приложении:")

@dp.message(MainStates.wait_telethon_code)
async def telethon_receive_code(msg: Message, state: FSMContext):
    code = msg.text.strip()
    data = await state.get_data()
    api_id = data["telethon_api_id"]
    api_hash = data["telethon_api_hash"]
    phone = data["telethon_phone"]
    session_path = data["telethon_session_path"]
    client = TelegramClient(session_path, api_id, api_hash)
    try:
        await client.connect()
        # Попытка sign_in
        try:
            await client.sign_in(phone=phone, code=code)
        except tele_errors.SessionPasswordNeededError:
            # запрашиваем пароль 2FA
            await client.disconnect()
            await state.set_state(MainStates.wait_telethon_password)
            await msg.answer("Активирована двухфакторная аутентификация. Введите пароль аккаунта:")
            return
        # если всё ок
        me = await client.get_me()
        await client.disconnect()
        # отправляем файл сессии пользователю
        sess_file = os.path.join(SESSIONS_DIR, os.path.basename(session_path))
        # Telethon уже создал .session в указанном пути
        if os.path.exists(session_path):
            await msg.answer_document(document=FSInputFile(session_path), caption=f"Готово. Авторизован: @{getattr(me, 'username', '')} ({me.id})")
        else:
            await msg.answer("Сессия создана, но файл не найден. Проверь конфигурацию папки.")
    except tele_errors.PhoneCodeInvalidError:
        await msg.answer("Неверный код.")
    except Exception as e:
        await msg.answer(f"Ошибка при входе: {e}")
    finally:
        try:
            await client.disconnect()
        except: pass
        await state.clear()

@dp.message(MainStates.wait_telethon_password)
async def telethon_receive_password(msg: Message, state: FSMContext):
    pwd = msg.text.strip()
    data = await state.get_data()
    api_id = data["telethon_api_id"]
    api_hash = data["telethon_api_hash"]
    phone = data["telethon_phone"]
    session_path = data["telethon_session_path"]
    client = TelegramClient(session_path, api_id, api_hash)
    try:
        await client.connect()
        await client.sign_in(password=pwd)
        me = await client.get_me()
        await msg.answer_document(document=FSInputFile(session_path), caption=f"Готово. Авторизован: @{getattr(me, 'username', '')} ({me.id})")
    except Exception as e:
        await msg.answer(f"Ошибка при вводе пароля: {e}")
    finally:
        try:
            await client.disconnect()
        except: pass
        await state.clear()

# ---------- Create Pyrogram session flow ----------
@dp.callback_query(F.data == "create_pyrogram")
async def cb_create_pyrogram(cb: CallbackQuery, state: FSMContext):
    await state.set_state(MainStates.wait_pyro_api)
    await cb.message.answer(
        "Создание Pyrogram-сессии.\n"
        "Отправь api_id и api_hash в формате <code>api_id:api_hash</code> (оба значения получены через my.telegram.org)."
    )

@dp.message(MainStates.wait_pyro_api)
async def pyro_receive_api(msg: Message, state: FSMContext):
    text = msg.text.strip()
    if ":" not in text:
        await msg.answer("Неверный формат. Ожидаю <code>api_id:api_hash</code>.")
        return
    api_id_s, api_hash = text.split(":", 1)
    try:
        api_id = int(api_id_s.strip())
    except:
        await msg.answer("api_id должен быть числом.")
        return
    await state.update_data(pyro_api_id=api_id, pyro_api_hash=api_hash.strip())
    await state.set_state(MainStates.wait_pyro_phone)
    await msg.answer("Теперь введите номер телефона аккаунта (в международном формате).")

@dp.message(MainStates.wait_pyro_phone)
async def pyro_receive_phone(msg: Message, state: FSMContext):
    phone = msg.text.strip()
    data = await state.get_data()
    api_id = data["pyro_api_id"]
    api_hash = data["pyro_api_hash"]
    session_name = f"pyro_{msg.from_user.id}_{int(time.time())}"
    session_path = os.path.join(SESSIONS_DIR, session_name)  # pyrogram создает session_name + .session
    # используем Pyrogram async client
    # для Pyrogram flow: сначала create client, then start() и подождать кода
    await state.update_data(pyro_session_name=session_name, pyro_session_path=session_path, pyro_phone=phone)
    # Создаём временный клиент и отправляем код
    app = PyroClient(session_name, api_id=api_id, api_hash=api_hash)
    await msg.answer("Отправляю код, ожидайте. Когда придёт — пришлите его сюда.")
    try:
        await app.connect()
        # send code
        await app.send_code(phone)
        await app.disconnect()
    except Exception as e:
        await msg.answer(f"Ошибка при отправке кода: {e}")
        await state.clear()
        return
    await state.set_state(MainStates.wait_pyro_code)

@dp.message(MainStates.wait_pyro_code)
async def pyro_receive_code(msg: Message, state: FSMContext):
    code = msg.text.strip()
    data = await state.get_data()
    api_id = data["pyro_api_id"]
    api_hash = data["pyro_api_hash"]
    phone = data["pyro_phone"]
    session_name = data["pyro_session_name"]
    session_path = data["pyro_session_path"]
    app = PyroClient(session_name, api_id=api_id, api_hash=api_hash)
    await msg.answer("Пробую зайти...")
    try:
        await app.connect()
        # Pyrogram: sign_in requires phone and code; if 2fa -> SessionPasswordNeeded
        try:
            await app.sign_in(phone_number=phone, code=code)
        except SessionPasswordNeeded:
            await app.disconnect()
            await state.set_state(MainStates.wait_pyro_password)
            await msg.answer("Требуется пароль (2FA). Введите пароль аккаунта:")
            return
        # success
        me = await app.get_me()
        await app.disconnect()
        # Pyrogram создает файл session_name.session в cwd (или в sessions dir if path given)
        # Move file to sessions dir (pyrogram stored session in current dir by default)
        src = f"{session_name}.session"
        if os.path.exists(src):
            dst = os.path.join(SESSIONS_DIR, src)
            os.replace(src, dst)
            await msg.answer_document(document=FSInputFile(dst), caption=f"Готово. Авторизован: @{getattr(me, 'username', '')} ({me.id})")
        else:
            await msg.answer("Сессия создана, но файл не найден. Возможно Pyrogram сохранил в другом месте.")
    except Exception as e:
        await msg.answer(f"Ошибка при входе (Pyrogram): {e}")
    finally:
        try:
            await app.disconnect()
        except:
            pass
        await state.clear()

@dp.message(MainStates.wait_pyro_password)
async def pyro_receive_password(msg: Message, state: FSMContext):
    pwd = msg.text.strip()
    data = await state.get_data()
    api_id = data["pyro_api_id"]
    api_hash = data["pyro_api_hash"]
    phone = data["pyro_phone"]
    session_name = data["pyro_session_name"]
    app = PyroClient(session_name, api_id=api_id, api_hash=api_hash)
    try:
        await app.connect()
        await app.check_password(pwd)  # raises if fails
        me = await app.get_me()
        await app.disconnect()
        src = f"{session_name}.session"
        if os.path.exists(src):
            dst = os.path.join(SESSIONS_DIR, src)
            os.replace(src, dst)
            await msg.answer_document(document=FSInputFile(dst), caption=f"Готово. Авторизован: @{getattr(me, 'username', '')} ({me.id})")
        else:
            await msg.answer("Сессия создана, но файл не найден.")
    except Exception as e:
        await msg.answer(f"Ошибка при вводе пароля (Pyrogram): {e}")
    finally:
        try:
            await app.disconnect()
        except:
            pass
        await state.clear()

# ---------- Fallback handler ----------
@dp.message()
async def fallback(msg: Message):
    await msg.answer("Я работаю с inline-меню. Нажми /start или выбери опцию.", reply_markup=main_kb())

# ---------- Run ----------
async def main():
    logger.info("Starting bot...")
    await dp.start_polling(bot)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        logger.info("Bot stopped.")